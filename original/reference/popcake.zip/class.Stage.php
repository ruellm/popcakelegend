<?php
	class Stage
	{
		var $stageWidth;
		var $stageHeight;
		var $stageOrder;
		var $_imgArray = array();
		var $html;
		public function __construct($stageWidth = 3,$stageHeight = 3)
		{
			$this->stageHeight=$stageHeight;
			$this->stageWidth=$stageWidth;
			
		}
		public function displayStage()
		{
			
			for($i=0;$i<sizeOf($this->_imgArray);$i++)
			{
				$this->html .="<img src='img/".$this->_imgArray[$i].".png' class=".$this->_imgArray[$i].">";
			}
			return $this->html;
		}
		public function makeStage($maxImg)//$noOfChallenges
		{
			$imgArray = array();
			$imgClass = range(0,$maxImg);
			
			shuffle($imgClass);

			for($k=0;$k<9;$k++)
			{
				$imgArray[$k]=$imgClass[$k];
				$this->_imgArray[$k]=$imgClass[$k];
				//$this->html .= $imgClass[$k];
			}
			
		}
		
	}
?>