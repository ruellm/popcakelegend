<?php
session_start();
class ScoringSys
{
    var $noOfHits;
	public function __construct()
	{
		if(empty($_SESSION['totalHits'])) // Resets totalhits
		{
			$_SESSION['totalHits'] = 60; // Total hits for each level
		}
		if(empty($_SESSION['hits'])) // Reset Hits
		{
			$_SESSION['hits'] = 0;
		}
		if(empty($_SESSION['correctHits'])) // Reset correct Hits
		{
			$_SESSION['correctHits'] = 1;
		}
	}
	public function calculateScore($isCorrectHit) // If correct hit
	{
		if($isCorrectHit=="true") // Checks if true then score increases and correct hit increses
		{
			if(empty($_SESSION['score'])) // Resets score
			{
				$_SESSION['score'] = 10;
				$_SESSION['correctHits']++;
			}
			else
			{
				$_SESSION['score'] = ($_SESSION['correctHits'] *10) + $_SESSION['score'];
				$_SESSION['correctHits']++;
			
			}
				$_SESSION['hits']++;
			//$this->noOfCorrectHits++;
		}
		else
		{
			$_SESSION['correctHits']=1;
			$_SESSION['hits']++;
			//$this->noOfCorrectHits = 1;	
		}
		
	}
}
?>