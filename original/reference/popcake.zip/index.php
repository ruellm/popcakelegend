<php

?>
<!doctype html>
<html>
<head>
	<title>popCake</title>
	<link rel="Stylesheet" href="button_css.css">
    <style>
        #mainCont
        {
         position:fixed;
    top: 50%;
    left: 50%;
    width:400px;
    height:400px;
    margin-top: -200px; /*set to a negative number 1/2 of your height*/
    margin-left: -200px; /*set to a negative number 1/2 of your width*/
    //border: 1px solid #ccc;
    //background-color: #f3f3f3;
    text-align:center;
        }
    </style>
</head>
<body oncontextmenu="return false">
<script>
  window.fbAsyncInit = function() {
    FB.init({
      appId      : '1512894472287999',
      xfbml      : true,
      version    : 'v2.1'
    });
    // yahan p copy kya hai
    function onLogin(response) {
  if (response.status == 'connected') {
    FB.api('/me?fields=first_name', function(data) {
      var welcomeBlock = document.getElementById('fb-welcome');
      welcomeBlock.innerHTML = 'Hello , ' + data.first_name + '!';   
    });
    FB.api('/me', {fields: 'id'}, function(response) {
        var welcomeBlock = document.getElementById('fb-lastname');
        welcomeBlock.innerHTML = '<img src="http://graph.facebook.com/'+ response.id +'/picture"> '; 
    });
  }
}

FB.getLoginStatus(function(response) {
  // Check login status on load, and if the user is
  // already logged in, go directly to the welcome message.
  if (response.status == 'connected') {
    onLogin(response);
  } else {
    // Otherwise, show Login dialog first.
    FB.login(function(response) {
      onLogin(response);
    }, {scope: 'user_friends, email'});
  }
});
    // ADD ADDITIONAL FACEBOOK CODE HERE
  };

  (function(d, s, id){
     var js, fjs = d.getElementsByTagName(s)[0];
     if (d.getElementById(id)) {return;}
     js = d.createElement(s); js.id = id;
     js.src = "//connect.facebook.net/en_US/sdk.js";
     fjs.parentNode.insertBefore(js, fjs);
   }(document, 'script', 'facebook-jssdk'));
</script>
<div id="mainCont">
<h2 style="font-size:14px;" id="fb-welcome"></h2><br>
<p id="fb-lastname"></p>

<a class="btn pos" href="stage5.php">Ready to Bake?</a>
</div>
</body>
</html>