<?php
session_start();
$_SESSION['board'];
class Stage2
{
	
	var $html;
	public function __construct()
	{
		
	}// End of Constructor
	
	public function makeStage($challengeCardNumber)
	{
		if($challengeCardNumber==0) // It checks if the challenge number is 0, It indicated that level is complete
		{
			$_SESSION['board']=""; // Reset the board
			$randImage = range(0,8); // Generate random number from 0 to 8 (because white icons are not allowed in first level)
		
			shuffle($randImage); // Shuffle the randImage
			for($i=0;$i<sizeOf($randImage);$i++)
			{
                if($randImage[$i]==6 || $randImage[$i]==7 || $randImage[$i]==8)
                {
                    $_SESSION['board'] .= "<img src='img/6.png' class='6'>"; // Concatinate the img tag of HTML in session
                }
                else
                {
				    $_SESSION['board'] .= "<img src='img/".$randImage[$i].".png' class='".$randImage[$i]."'>"; // Concatinate the img tag of HTML in session
                }
			}
		}
		else
		{
			
		}
	}// End of makeStage
}
?>