var seconds2 = 14;
function secondPassed2() {
    var minutes2 = Math.round((seconds - 30)/60);
    var remainingSeconds2 = seconds2 % 60;
    if (remainingSeconds2 < 10) {
        remainingSeconds2 = "0" + remainingSeconds2;  
    }
    document.getElementById('challengeTime').innerHTML = minutes2 + ":" + remainingSeconds2;
    if (seconds2 == 0) {
        clearInterval(countdownTimer2);
        document.getElementById('challengeTime').innerHTML = "Let the game begin";
    } else {
        seconds2--;
    }
}
