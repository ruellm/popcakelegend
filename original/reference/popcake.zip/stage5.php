<?php
session_start();

include("stage.class.php"); /* Stage Class for making Board */
include("challengeCards.class.php"); /* ChallengeCards class for making challenge Cards */
include("scoringSystem2.class.php"); /* To controll scoring and hit system */

/* It counts the challenge. because we want to shuffle baord in every 10challenge */
/* Starts */
if(isset($_POST["submit"]))
{
    $hidden=$_POST["hidden"];
	//$_SESSION['score'] = $_POST['score'];
	
	if($hidden==10)
	{
		$x=0;
	}
	else
	{
	
		$x=$hidden +1;
	}
}
else
{
	$x=0;
}
/* Ends */

$makeStage =new Stage2(); /* Object for Board Class, namely "Stage2"*/
$makeChallenge =new ChallengeCards2();  /* Object for Challenge Class, namely "challengecards2"*/

$_lives = 5; /* I didn't use this variable */

$makeStage->makeStage($x); /* makeStage is a function which gets number of challenge and checks it challenge is 10th so it can reshuffle the board */
$makeChallenge->makeChallengeCard($x); /* It generates challenge card, it gets number of challenge to generate new challenge different from previous */

$makeChallenge->buildChallenge(); /* It assing challengecard in session variable*/

$_board = $_SESSION['board']; //$makeStage->html; /* This session variable has board's images in it */
$_challenge = $makeChallenge->challengeCardSet; /* This variable contain challengecards */


?>
<!doctype html>
<html>
<head>
	<title>Popcake</title>
	<link rel="Stylesheet" href="stage_style.css"> <!-- This contain css of whole page -->
    <link rel="Stylesheet" href="button_css.css"> <!-- This contain css of buttons ("Main menu","Ready to bake") -->
    <!-- <script type="text/javascript" src="js/jquery.min.js"></script> -->
    <script src="//code.jquery.com/jquery-1.10.2.js"></script>
   <!-- <script type="text/javascript" src="js/jquery.timer.js"></script>-->
	<!--<script src="js/jquery.js"></script>-->
    <script src="js/timer.js"></script>    <!-- This is timer class which is placed above our board -->
  
	<!--
	<script type="text/javascript">	
		var count = 30;
		var timer = $.timer(
			function() {
				count--;
				$('#challengeTime').html(count);
			},
			1000,
			true
		);
	</script>
	-->
	<script>
		var flag=0; /* It checks if 15seconds has passed. */
		var chk = 1; /* It checks any of the icon is clicked. */
		$(document).ready(function(){
			
			$(".challengeCardsDiv").hide(); /* It hides the challengecard, when page reloads */
			var board = "<?php echo $_board; ?>"; /* send board variable to javascript board variable */
			var challenge = "<?php echo $_challenge; ?>"; /* send challengecard variable to javascript challengecard variable */
			
			
			
			var lives = "<?php echo $_lives; ?>"; /* send live variable to javascript live variable */
			var correct_hits = 0; /* counts correct hits */
			var checkChallengeNo = "<?php echo $x;?>"; /* counts challenge number */
			var flipTime = 16*1000; /* Time to hide the board at starting each level */
		
			$("#stage").html(board); /* Sets board on HTML canvas */
			$("#challengeCards .challengeCardsDiv").html(challenge); /* Sets challenge on HTML canvas */
			
			if(checkChallengeNo==0) /* Checks challenge, if it is 0 then countdown timer shows */
			{
				setTimeout(function(){
					$("#stage img").attr("src","img/flip.png").fadeIn("slow"); // It changes the image after 16 seconds (16 seconds can be change by changing value of flipTime varibale)
               		$(".challengeCardsDiv").fadeIn("slow"); /* Shows challenge card after 16 secs*/
               		 flag=1; /* It allows clicking on board */
				},flipTime);
			}
			else /* Checks challenge, if it is not 0 then countdown timer hides */
			{
				$("#stage img").attr("src","img/flip.png").fadeIn("fast"); // It keeps hiding the icon on board for each level
				$("#countdown").hide(); // hides countdown timer of the board
				$(".challengeCardsDiv").fadeIn("slow"); // shows challenge card
				flag=1; // allows clicking
			}
			
			var noOfChallengeCards = $("#challengeCards .challengeCardsDiv img").length; /* Counts the length of challengecard */
			
			$("#stage img").click(function(e){ /* Gets each click on the board */
			if(flag==0) /* It prevents user from clicking the board before timer ends*/
			{
				e.preventDefault();
			}
			else
			{
				if(chk==1) /* Check if icon on the board is clicked */
				{
					var getImgClass = $(this).attr("class"); /* Gets class of the image on the board */
					if($("#challengeCards .challengeCardsDiv img").hasClass(getImgClass)) // Checks, if image class, which we got from board exists in our challengecardset
					{
						

						$("#challengeCards .challengeCardsDiv ."+getImgClass).attr("src","img/"+getImgClass+"-tick.png"); // If image class on board matches with challengecard then image on challengecard replace with tick image
						$("#stage ."+getImgClass).attr("src","img/"+getImgClass+".png"); /* correct image on board stays visible for whole challenge. */
						
						// This ajax sends indication to functions, it sends "true" parameter
						// this also sets "score" and" hits" on the html element
						// It also decreases the hit counter
						// It gets div from "try_ajax_class.php" and sets it under "score" div
						// Starts
						$.ajax({
       	        			 type: 'POST',
        	        		 url: 'try_ajax_class.php',
        	       			 data: {
        	       			 	src2:"true"
        	      			  },
         	     			  success: function(data) {	         	
            	    		}
            			});
            			// Ends
						correct_hits++; // increment to correct hit counter
   	             
						
					}
					else
					{
						// This ajax sends indication to functions, it sends "false" parameter
						// this also sets "score" and" hits" on the html element
						// It gets div from "try_ajax_class.php" and sets it under "score" div
						// Starts
						$.ajax({
       	        			 type: 'POST',
        	        		 url: 'try_ajax_class.php',
        	       			 data: {
        	       			 	src2:"false"
        	      			  },
         	     			  success: function(data) {	         	
            	    		}
            			});  
						$("#stage ."+getImgClass).attr("src","img/"+getImgClass+".png");
					
						setTimeout(function(){
							$("#stage ."+getImgClass).attr("src","img/flip.png")
							//e.preventDefault();
						},3000);
						// Ends
					
					}
					chk=0;	// It prevents user from clicking the board before 1 second
				
			}
			else
			{
				setTimeout(function(){
					chk=1; // It allows user from clicking the board but only after 1 sec
				},1000);
			}
				if(correct_hits==noOfChallengeCards) // It number of correct hits are equals to challenge cards then the next challenge will appear
				{
					flag=0; // Allows user from clicking the board
					
					/* Submits function after 2 seconds, It make next challenge appears after 2secs*/
					setTimeout(function(){
						$("#submit").trigger("click",function(){
							alert("Clicked");
						});
					},2000);
					correct_hits = 0; // Correct hits reset to zero
				}
			}
			});
			
			/* Destroys the session */
			$("#btn3").click(function(){
      		  	$.ajax({
       	         type: 'POST',
        	        url: 'try_ajax_class.php',
        	        data: {
        	        	src2:"dest"
        	        },
         	       success: function(data) {
						//alert(data);
            	     	         	
            	    }
            	});  
            	window.location.href = "index.php";		
     	   });
		});
	</script>
	<script>
	/* It updates div ".score m" after every 1 seconds */
	$(document).ready(
   	         function() {
   	             setInterval(function() {
    	                $(".score m").load("try_ajax_class.php#score");
    	               // $(".hits m").load("try_ajax_class.php#hits");
     	           }, 1000);
     	 });
	</script>
</head>
<body > <!-- oncontextmenu="return false" <= This code prevents user from "Right clicking" our board -->

		<div id="cont">
			<div class="score" style="width:125px;">Score : <m></m>
			</div>
			<div class="hits" style="width:100px;">Hits : <m></m>
			</div>
			<div class="lives">Lives : <m></m>
			</div>
			<div class="challengeTimeLoader" id="countdown">
			</div>
			<div id="stageCont">
				<div id="challengeTime" class="abc">
				</div>
				<div id="stage">
				
				</div>
			</div>
			<div id="challengeCards">
				<div class="challengeCardsDiv">
					
				</div>
			</div>
				<form method="POST" action="" id="myForm">
					<input type=submit id="submit" name="submit" value="" style="display:none;"/>
					<input type="hidden" name="hidden" id="hidden" value="<?php echo $x; ?>" />
				</form>
                <button id="btn3" class="btn">Main Menu</button>
		</div>
		
	</body>
</html>