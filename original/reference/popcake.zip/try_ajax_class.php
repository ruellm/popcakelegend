<?php
session_start();

include("scoringSystem2.class.php");
$sc = new ScoringSys();

$src2 = $_POST['src2']; // gets variable from stage5.php

if($src2 == "")
{    
	//echo "Variable is empty";
}
else
{
	if($src2 == "dest") // destroys the session
	{
		session_destroy();
		echo "Session Destroyed";
	}
	else
	{
		$sc->calculateScore($src2); // sends True or False value to the function from Stage5.php
		echo "Function Access";
	}
}

?>
<!-- Below this line, both divs are send to Stage5.php and sets on respective divs -->
<div id="score">
<?php
if($_SESSION['score']!="")
{
	echo $_SESSION['score']; 
}
else
{
	echo "0";
}
?>
</div>

<div id="hits">
<?php
if($_SESSION['hits']!="")
{
	echo ($_SESSION['totalHits'] - $_SESSION['hits']);
}
else
{
	echo $_SESSION['totalHits'];
}
?>
</div>
