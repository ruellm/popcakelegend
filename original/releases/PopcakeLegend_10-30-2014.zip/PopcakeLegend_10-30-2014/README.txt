PopcakeLegend_10-30-2014 (version 0.0.059)

Changes for this release
1. Fixes on Bug 16, 17, 18, 19, 20, 22, 23.
	QA report #21 is not a bug
	QA report #24 please forward to artist to create arts for main menu
	
2. Added/integrated new features:
All change reflect from specifcation of: 
(Front End Screen Architecture Front End - Level 1-3 tutorial - WG - 23 oct 2014.pptx)
	a. Switching of icons is now moving
	b. Glowing when hits reached 5 or less
	c. Message when the board is switching
	d. Cancel Board move button is now functioning.
	e. Purchase extra hits and time can already be found in challenge box.
	
