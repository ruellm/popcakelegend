PopcakeLegend_10-21-2014(gameplay)_2fix:
	Release 0.0.034 (Initial Non-Alpha)
	
------------------------------------------------------------------------------------------------------------------
IMPORTANT NOTES!!

1. The release game features the game play described in the excel sheet(Popcakes-Detailed Design...xls)

2. The release game follows the screens that is described in the documents sent only, meaning if there are no screens
in the documents, then it is not implemented, for missing screens please refer to: last section of this README file.

The following documents are used for this development:
Popcakes - Detailed Design for 10 Levels.xls
Front End Screen Architecture Front End - Level 1 tutorial - WG - 13 oct 2014.pptx

The following features are not yet supported:
1. Any thing related to facebook handling and monetization.

2. Any thing related to MONETIZATION BUTTONS except for Shuffle as described in the power point document. 
when Reshuffle button is clicked, the board is reshuffled but no coins are dedcuted.

3. No coins handling yet as this involves actual data storing and in-app purchase.

4. No screens such as: General Level screen, etc. No arts has been given yet

5. Initialy there are only 3 information on top of the game play as described in concept art (PlayingScreen.jpg) and powerpoint (Front End....pptx).
These informations are Score, Hits and Coins only.
However information such as Current Level, Life and Total Score are needed by the player as information while playing thru the levels and challenges. 
These two informations were added to the game to add more information to the player.

------------------------------------------------------------------------------------------------------------------
TO Followup to artists and project manager:
Needs arts and specification documents for the following:

1. where is the bakery store
2. currently the release is using my own version of Popup window during;
	1. level complete
    2. game over: when hits, life, time are over
		
	Do the have a plan for the art style of the pop-up window described above?
	
3. chocolate coins contest? needs specification
4. who will do the music? where are the music?
5. where is the general levels screen?
6. leaderboard screen?
7. buttons for sharing, inviting, offering gifts.
8. Level progress bar
9. In the documents sent, there is nowhere found the information to player's introduction to a certain level.
   can we put a window that describes the objective of the level?
   example: Level 7 popup: 
			Objective: Reach a minimum of Bronze trophy to complete the level			
			[OK]
			