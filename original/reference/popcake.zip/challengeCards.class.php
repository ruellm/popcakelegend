<?php
class ChallengeCards2
{
	var $challengeCardHolder;
	var $challengeCardSet;
	var $challengeCardSetNumber;
	
	public function __construct()
	{
		
	} // End of constructor
	
	public function makeChallengeCard($challengeCardSetNumber)
	{
		$this->challengeCardSetNumber = $challengeCardSetNumber;
		$maxCards = 8;
		
		$k=2;
		for($i=0;$i<11;$i++)
		{
			$randChallenges = range(0,$maxCards);
			shuffle($randChallenges);
			for($j=0;$j<$k;$j++)
			{
				if($randChallenges[$j]==6 || $randChallenges[$j]==7 || $randChallenges[$j]==8)
    			{
					$this->challengeCardHolder[$i][$j] = 6;
				}
				else
				{
					$this->challengeCardHolder[$i][$j] = $randChallenges[$j];
				}
			}
			$k++;
			if($k>4)
			{
				$k=2;
			}		
		
		}
	}
	
	function buildChallenge()
	{
		for($i=0;$i<sizeOf($this->challengeCardHolder);$i++)
		{
			if($i==$this->challengeCardSetNumber)
			{
				for($j=0;$j<sizeOf($this->challengeCardHolder[$i]);$j++)
				{
				
					$this->challengeCardSet .= "<img src='img/".$this->challengeCardHolder[$i][$j].".png' class=".$this->challengeCardHolder[$i][$j].">";
				
				}
			}
			else
			{
				continue;
			}
		
		}
	}
}		
?>